import json

def main(event, context):
    print("hello!")
